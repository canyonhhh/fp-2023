{-# LANGUAGE DeriveFunctor #-}
{-# OPTIONS_GHC -Wno-unused-top-binds #-}
{-# OPTIONS_GHC -Wno-name-shadowing #-}
{-# OPTIONS_GHC -Wno-partial-fields #-}

module Lib3
  ( executeSql,
    Execution,
    ExecutionAlgebra(..),
  )
where

import Control.Monad.Free (Free (..), liftF)
import DataFrame
import Lib2
import Data.Time (UTCTime)
import Data.Foldable (all)
import qualified Data.Yaml as Y
import qualified Data.ByteString as B
import Control.Monad.IO.Class (liftIO)
import Data.Maybe (fromMaybe)


-- columns:
  -- - name: ID
    -- type: IntegerType
  -- - name: Name
    -- type: StringType
  -- - name: Active
    -- type: BoolType

--rows:
  -- - [1, "Alice", true]
  -- - [2, "Bob", false]

instance Y.FromJSON ColumnType where
    parseJSON (Y.String "IntegerType") = pure IntegerType
    parseJSON (Y.String "StringType") = pure StringType
    parseJSON (Y.String "BoolType") = pure BoolType
    parseJSON _ = fail "Invalid ColumnType"

instance Y.FromJSON Column where
    parseJSON (Y.Object v) = Column
        <$> v .: "name"
        <*> v .: "type"
    parseJSON _ = fail "Invalid Column"

instance Y.FromJSON Value where
    parseJSON (Y.String s) = pure $ StringValue s
    parseJSON (Y.Number n) = pure $ IntegerValue (round n) -- Assuming all numbers are integers
    parseJSON (Y.Bool b) = pure $ BoolValue b
    parseJSON Y.Null = pure NullValue
    parseJSON _ = fail "Invalid Value"

instance Y.FromJSON DataFrame where
    parseJSON (Y.Object v) = DataFrame
        <$> v .: "columns"
        <*> (v .: "rows" >>= mapM parseRow)
    parseJSON _ = fail "Invalid DataFrame"

parseRow :: Value -> Y.Parser Row
parseRow (Y.Array arr) = mapM parseJSON (V.toList arr)
parseRow _ = fail "Invalid Row"

loadFile :: TableName -> Execution FileContent
loadFile name = liftIO $ B.readFile (name ++ ".yaml")

parseDataFrame :: FileContent -> DataFrame
parseDataFrame fileContent = case Y.decodeEither' fileContent of
    Left errMsg -> error errMsg
    Right tableYaml -> DataFrame (map parseColumn (Lib2.columns tableYaml)) (map parseRow (rows tableYaml))

type TableName = String
type Cname = String
type FileContent = String
type ErrorMessage = String

data ExecutionAlgebra next
  = LoadFile TableName (FileContent -> next)
  | GetTime (UTCTime -> next)
  | ParseDataFrame FileContent (DataFrame -> next)
  | FilterRows Condition DataFrame (DataFrame -> next)
  | SelectColumns [(Aggregate, Maybe TableName, Cname)] DataFrame (DataFrame -> next)
  | JoinTables [(Maybe TableName, Cname)] [(Maybe TableName, Cname)] DataFrame DataFrame (DataFrame -> next)
  | InsertInto TableName Row (Either ErrorMessage () -> next)
  | UpdateTable TableName [(Cname, Value)] (Maybe Condition) (Either ErrorMessage () -> next)
  | DeleteFrom TableName (Maybe Condition) (Either ErrorMessage () -> next)
  | ShowTables (Either ErrorMessage [TableName] -> next)
  | ShowTableStructure TableName (Either ErrorMessage DataFrame -> next)
  | SaveTableData TableName DataFrame (Either ErrorMessage () -> next)
  | AggregateData Aggregate DataFrame (DataFrame -> next)
  | ReportError ErrorMessage next
  deriving Functor

type Execution = Free ExecutionAlgebra

getTime :: Execution UTCTime
getTime = liftF $ GetTime id

-- Placeholder function to execute SQL commands
executeSql :: String -> Execution (Either ErrorMessage DataFrame)
executeSql sql = case parseStatement sql of
    Left errMsg -> return $ Left errMsg
    Right stmt -> case stmt of
        ShowTable tableName -> do
            fileContent <- loadFile tableName
            return $ Right $ parseDataFrame fileContent
        Lib2.ShowTables -> do
            fileContent <- loadFile "tables.yaml"
            return $ Right $ parseDataFrame fileContent
        SelectAll tableName -> do
            fileContent <- loadFile tableName
            let df = parseDataFrame fileContent
            return $ Right filteredDf
        Select tableNames whereClause columns -> do
            case length tableNames of
                1 -> do
                    fileContent <- loadFile (head tableNames)
                    let df = parseDataFrame fileContent
                    filteredDf <- filterRows whereClause df
                    aggregateDf <- aggregateData columns filteredDf
                    let selectedDf = selectColumns columns aggregateDf
                    return $ Right selectedDf
                2 -> do
                    fileContent1 <- loadFile (head tableNames)
                    fileContent2 <- loadFile (last tableNames)
                    let df1 = parseDataFrame fileContent1
                    let df2 = parseDataFrame fileContent2
                    filteredDf1 <- filterRows whereClause df1
                    filteredDf2 <- filterRows whereClause df2
                    aggregateDf1 <- aggregateData columns filteredDf1
                    aggregateDf2 <- aggregateData columns filteredDf2
                    let selectedDf = joinTables columns aggregateDf1 aggregateDf2
                    return $ Right selectedDf
                _ -> return $ Left "Joining more than 2 tables is not supported"
        Insert tableName values -> do
            fileContent <- loadFile tableName
            let df = parseDataFrame fileContent
            let newRow = parseRow values
            let newDf = insertInto df newRow
            saveTableData tableName newDf
            return $ Right newDf
        Update tableName values whereClause -> do
            fileContent <- loadFile tableName
            let df = parseDataFrame fileContent
            let updatedDf = updateTable df values whereClause
            saveTableData tableName updatedDf
        Delete tableName whereClause -> do
            fileContent <- loadFile tableName
            let df = parseDataFrame fileContent
            let updatedDf = filterRows whereClause df
            saveTableData tableName updatedDf
        _ -> return $ Left "Unsupported statement"
